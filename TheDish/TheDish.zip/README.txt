Installation should be a straightforward download and install.Git = https://github.com/Justin-Hinds/Portfolio/



