Installation should be a straightforward download and install.Git = https://github.com/Justin-Hinds/Portfolio/


Features: Posting with text images and links, commenting on posts, friending, up and downs with sorting.
