Installation should be a straightforward download and install.Git = https://github.com/Justin-Hinds/Portfolio/tree/master/Sticks
Features messaging, posting, comments, friending, hyperlinks sent to default browser.
