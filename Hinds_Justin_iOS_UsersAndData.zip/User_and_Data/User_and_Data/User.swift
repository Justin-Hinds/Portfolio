//
//  User.swift
//  User_and_Data
//
//  Created by Justin Hinds on 11/8/17.
//  Copyright © 2017 Justin Hinds. All rights reserved.
//

import Foundation

class User: NSObject {
    var name : NSString?
    var age : NSNumber?
}
