//
//  CreateAccountViewController.swift
//  User_and_Data
//
//  Created by Justin Hinds on 11/7/17.
//  Copyright © 2017 Justin Hinds. All rights reserved.
//

import UIKit
import Firebase
class CreateAccountViewController: UIViewController {

    @IBOutlet weak var emailText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var ageText: UITextField!
    
    @IBAction func createAction(_ sender: Any) {
        if let email = emailText.text, let password = passwordText.text, let name = nameText.text, let age = ageText.text{
            FIRAuth.auth()?.createUser(withEmail: email, password: password, completion: { (user, error) in
                if let error = error{
                    return
                }
                self.addFirUser()
            })
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    func addFirUser() -> Void {
       let ref = FIRDatabase.database().reference().child("Users").child((FIRAuth.auth()?.currentUser?.uid)!)
        if let name = nameText.text, let realAge = NumberFormatter().number(from: ageText.text!){
            ref.setValue(["name":name, "age" : realAge])
        }else{
            ref.setValue(["name":"name", "age" : 99])
        }
        let vc = storyboard?.instantiateViewController(withIdentifier: "MainNav")
        present(vc!, animated: true, completion: nil)
        
    }


    
}
