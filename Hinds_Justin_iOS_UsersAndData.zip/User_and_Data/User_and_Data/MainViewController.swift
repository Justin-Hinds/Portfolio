//
//  ViewController.swift
//  User_and_Data
//
//  Created by Justin Hinds on 11/5/17.
//  Copyright © 2017 Justin Hinds. All rights reserved.
//

import UIKit
import Firebase
class MainViewController: UIViewController {

    @IBOutlet weak var nameText: UILabel!
    @IBAction func logoutAction(_ sender: Any) {
        
        let firebaseAuth = FIRAuth.auth()
        do {
            try firebaseAuth?.signOut()
            let vc = storyboard?.instantiateViewController(withIdentifier: "Login")
            present(vc!, animated: true, completion: nil)
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
    }
    @IBOutlet weak var ageText: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       
    }
    override func viewDidAppear(_ animated: Bool) {
        let user = FIRAuth.auth()?.currentUser
        if (user) != nil{
            print(FIRAuth.auth()?.currentUser?.email! ?? "n/a")
            let ref = FIRDatabase.database().reference().child("Users").child((user?.uid)!)
            ref.observe(.value, with: { (snapshot) in
                if let dictionary = snapshot.value as? [String : AnyObject]{
                    //let currentUser = User()
                    print(dictionary)
                    //currentUser.setValuesForKeys(dictionary)
                    self.nameText.text = dictionary["name"] as? String ?? "N/A"
                    self.ageText.text = "\(String(describing: dictionary["age"] ?? "N/A" as AnyObject))"                 }
            })
            
        }else{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "Login")
            present(vc!, animated: true, completion:  nil)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

